CDIR="$(cd "$(dirname "$0")" && pwd)"
cd $CDIR

[ ! -d run ] && ln -sf . run
./zsh -fc "typeset -p fpath" | sed "s,./run,$CDIR,g" > .zshenv

export ZDOTDIR=$CDIR
export PATH=$CDIR:$PATH
export ZSH_DISABLE_COMPFIX=true

./zsh "$@"