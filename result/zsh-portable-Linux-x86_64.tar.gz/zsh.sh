./zsh -fc "typeset -p fpath" | sed "s,./run,$PWD,g" > etc/zshenv  &&  ./zsh
